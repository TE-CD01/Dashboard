CDBU1 LAN WEB - วิธีติดตั้งบนเครื่อง Server (Windows)

โฟลเดอร์ข้อมูลที่ตั้งค่าไว้:
\10.150.208.54\shopfloor$	estdata\monitor

1) คัดลอกโฟลเดอร์ CDBU1_LAN ไปไว้บนเครื่อง PC ที่จะทำหน้าที่เป็น Server
2) เครื่อง Server ต้องเปิดใช้งานในวง LAN และต้องมีสิทธิ์อ่าน Shared Folder ด้านบน
3) ติดตั้ง Python 3.10 หรือใหม่กว่า (เลือก Add Python to PATH)
4) ดับเบิลคลิก run_windows.bat และรอให้ติดตั้ง Flask ครั้งแรก
5) เมื่อขึ้น Running on http://...:5000 ให้เปิด Command Prompt อีกหน้าต่างแล้วพิมพ์ ipconfig
6) ดู IPv4 Address ของ Ethernet เช่น 10.150.208.100
7) เครื่องอื่นในวง LAN เปิด Chrome/Edge ไปที่ http://10.150.208.100:5000

การทำงาน:
- Server สแกนไฟล์ ATS_ALL_YYYYMMDD*.csv หรือ .txt ใน Shared Folder
- Auto mode เลือกไฟล์ของวันล่าสุดตามจำนวน Latest days (ค่าเริ่มต้น 7 วัน)
- ตรวจไฟล์ใหม่/ไฟล์เปลี่ยนทุก 30 วินาที และโหลดข้อมูลใหม่อัตโนมัติ
- ปิด Auto ใน Files เพื่อเลือกไฟล์เอง
- ชื่อไฟล์ที่ไม่ตรง ATS_ALL_YYYYMMDD จะไม่ถูกนำเข้า
- ไฟล์ที่ header ต่างจากไฟล์แรกจะถูกข้ามพร้อม warning เพื่อป้องกันคอลัมน์เลื่อน

ข้อควรตั้งค่าก่อนใช้งานจริง:
- ให้บัญชี Windows ที่รัน app.py มีสิทธิ์ Read/List folder ที่ Shared Folder
- อนุญาต Windows Firewall inbound TCP port 5000 เฉพาะเครือข่าย Private/LAN
- อย่าเปิด port 5000 ออก Internet
- เครื่อง Server ต้องเปิดอยู่ตลอดเวลาที่ต้องการให้เครื่องอื่นใช้งาน
- ทุกเครื่องเห็นข้อมูลชุดเดียวกัน แต่ตัวกรอง/ธีมของหน้าเว็บเป็นการตั้งค่าของแต่ละ Browser

ทดสอบการเชื่อมต่อ:
เปิด http://SERVER-IP:5000/api/health ต้องได้ ok=true และ folder_accessible=true

หมายเหตุ: ระบบนี้คงหน้า CDBU1 และการประมวลผลฝั่ง Browser จากเวอร์ชัน v2 ไว้ โดยย้ายการอ่าน Shared Folder ไปทำบน Python Server เพราะ Browser ของแต่ละเครื่องไม่สามารถเข้าถึง UNC path กลางได้โดยตรง
