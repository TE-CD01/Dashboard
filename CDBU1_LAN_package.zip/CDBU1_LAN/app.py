from __future__ import annotations
import json
import os
import re
from pathlib import Path
from datetime import datetime
from flask import Flask, jsonify, request, render_template

APP_DIR = Path(__file__).resolve().parent
CONFIG_FILE = APP_DIR / 'line_config.json'
# Windows UNC share. Override with CDBU1_DATA_DIR if the server PC uses another path.
DATA_DIR = Path(os.environ.get('CDBU1_DATA_DIR', r'\\10.150.208.54\shopfloor$\testdata\monitor'))
FILE_RE = re.compile(r'^ATS_ALL_(\d{8})[^\\/]*\.(?:csv|txt)$', re.I)
app = Flask(__name__)


def scan_files(days: int = 7):
    if not DATA_DIR.exists() or not DATA_DIR.is_dir():
        raise FileNotFoundError(f'Cannot access shared folder: {DATA_DIR}')
    found = []
    for p in DATA_DIR.iterdir():
        if not p.is_file():
            continue
        m = FILE_RE.match(p.name)
        if not m:
            continue
        try:
            dt = datetime.strptime(m.group(1), '%Y%m%d')
            st = p.stat()
        except (ValueError, OSError):
            continue
        found.append({'name': p.name, 'size': st.st_size, 'mtime': int(st.st_mtime), 'date': dt.strftime('%Y-%m-%d')})
    found.sort(key=lambda x: (x['date'], x['name']))
    latest_dates = sorted({x['date'] for x in found})[-max(1, min(days, 31)):]
    for item in found:
        item['in_auto'] = item['date'] in latest_dates
    return found


def safe_file(name: str) -> Path:
    # Only allow a basename matching the expected daily log convention.
    if not isinstance(name, str) or not FILE_RE.match(name) or Path(name).name != name:
        raise ValueError(f'Invalid log filename: {name!r}')
    p = DATA_DIR / name
    if p.parent.resolve() != DATA_DIR.resolve() or not p.is_file():
        raise FileNotFoundError(f'File not found: {name}')
    return p


def read_and_merge(names: list[str]):
    if not isinstance(names, list) or not names:
        raise ValueError('No files selected')
    # Validate names before sorting; then keep older records before newer records.
    for name in names:
        if not isinstance(name, str) or not FILE_RE.match(name) or Path(name).name != name:
            raise ValueError(f'Invalid log filename: {name!r}')
    names = sorted(set(names), key=lambda n: (FILE_RE.match(n).group(1), n))
    chunks, header, warnings = [], None, []
    for name in names:
        p = safe_file(name)
        # Avoid reading a file while the producer is actively writing it.
        before = p.stat().st_size
        raw = p.read_bytes()
        after = p.stat().st_size
        if before != after:
            warnings.append(f'{name}: file changed while being read; skipped this cycle')
            continue
        text = raw.decode('utf-8-sig', errors='replace').strip()
        if not text:
            warnings.append(f'{name}: empty file')
            continue
        lines = text.splitlines()
        if header is None:
            header = lines[0]
            chunks.append(text)
        elif lines[0].strip() == header.strip():
            chunks.extend(lines[1:])
        else:
            warnings.append(f'{name}: header differs from first selected file; skipped to avoid corrupting columns')
    return '\n'.join(chunks), warnings, names


@app.get('/')
def home():
    return render_template('index.html')


@app.get('/api/health')
def health():
    return jsonify({'ok': True, 'data_dir': str(DATA_DIR), 'folder_accessible': DATA_DIR.is_dir()})


@app.get('/api/files')
def files():
    try:
        days = int(request.args.get('days', '7'))
        days = max(1, min(days, 31))
        items = scan_files(days)
        return jsonify({'files': items, 'data_dir': str(DATA_DIR), 'days': days})
    except Exception as exc:
        return jsonify({'error': str(exc), 'files': []}), 500


@app.post('/api/load')
def load():
    try:
        body = request.get_json(silent=True) or {}
        content, warnings, names = read_and_merge(body.get('names'))
        if not content:
            return jsonify({'error': 'No readable rows in selected files', 'warnings': warnings}), 422
        return jsonify({'content': content, 'warnings': warnings, 'files': names})
    except (ValueError, FileNotFoundError, PermissionError) as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        app.logger.exception('CSV load failed')
        return jsonify({'error': str(exc)}), 500


@app.get('/api/line-config')
def line_config():
    try:
        return jsonify(json.loads(CONFIG_FILE.read_text(encoding='utf-8')))
    except Exception:
        return jsonify({'carrier': 0, 'station': 0, 'tester': 0})


@app.get('/api/line-config/set')
def line_config_set():
    data = {k: max(0, min(999, int(request.args.get(k, '0') or 0))) for k in ('carrier', 'station', 'tester')}
    CONFIG_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    return jsonify(data)


if __name__ == '__main__':
    # Use the server PC's LAN IPv4 address in browsers on other PCs.
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', '5000')), debug=False, threaded=True)
